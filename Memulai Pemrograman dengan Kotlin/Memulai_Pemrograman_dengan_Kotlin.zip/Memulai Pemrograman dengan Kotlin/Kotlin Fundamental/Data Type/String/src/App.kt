// main function
fun main() {
    val text  = "Kotlin"
    val firstChar = text[0]

    print("First character of $text is $firstChar")
}