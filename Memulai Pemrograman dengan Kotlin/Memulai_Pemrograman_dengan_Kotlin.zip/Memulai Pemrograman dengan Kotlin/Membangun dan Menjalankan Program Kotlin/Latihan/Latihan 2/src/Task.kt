fun main() {
    println("Kotlin,")
    print("is Awesome!")
}